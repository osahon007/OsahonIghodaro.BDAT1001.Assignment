﻿using EncoderEncryterApp.Models;
using System;
using System.Text;
using System.Linq;


namespace EncoderEncryterApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // QUESTION 2
            // this inputs a string and saves as the variable myName
            Console.WriteLine("Please enter your full name: ");
            var myName = Console.ReadLine();

            // QUESTION 3
            // this calls the StringToBinary function and saves it as a variable BinaryValue
            string binaryValue = Converter.StringToBinary(myName);

            // QUESTION 4
            // this prints out the inputed text and the binary value equivalent in the console
            Console.WriteLine($"Full Name: {myName}\nBinary Equivalent of my Full Name: {binaryValue}");

            //QUESTION 5
            // this receives the binary output of the full Name variable and stores in myAscii variable
            Console.WriteLine("Please enter your enter the binary value of Full name: ");
            var myAscii = Console.ReadLine();

            //QUESTION 6
            //this calls the BinaryToString function and stores the ASCII value in textFrom Binary variable
            string textFromBinary = Converter.BinaryToString(myAscii);

            //this prints out the inputed binary and the ASCII equivalent
            Console.WriteLine($"Binary: {myAscii}\nFull Name: {textFromBinary}\n");

            //QUESTION 7a
            // this uses the string input from the full name variable and coverts to hexadecimal
            string hexadecimalValue = Converter.StringToHex(myName);

            //this prints out the inputed string and ist HEX equivalent
            Console.WriteLine($"Full Name: {myName}\nHEX: {hexadecimalValue}");

            // QUESTION 7b
            // this uses the output of Question 7a, stored in the variable hexadecimalValue and converts it back to ASCII
            string textFromHex = Converter.HexToString(hexadecimalValue);

            //this prints out that HEX value and its ASCII equivalent
            Console.WriteLine($"HEX: {hexadecimalValue}\nFull Name: {textFromHex}\n");

            //QUESTION 7c
            // this uses the string input from the text variable and coverts to Base64
            string nameBase64Encoded = Converter.StringToBase64(myName);

            //this prints out the Base64 equvalent of the input string
            Console.WriteLine("The Base64 equivalent of my Full name is :");
            Console.WriteLine(nameBase64Encoded);

            //QUESTION 7d
            // this uses the output of Question 7c, stored in nameBase64Encoded and returns a string
            Console.WriteLine("The string equivalent of Base64 code is :");
            string nameBase64Decoded = Converter.Base64ToString(nameBase64Encoded);

            //this prints out a string equvalent of the Base64 value stored in nameBase64Encoded
            Console.WriteLine(nameBase64Decoded);

            //QUESTION 8
            // https://www.c-sharpcorner.com/article/c-sharp-string-to-byte-array/
            // Requests input from user and saves in myfullname variable

            Console.WriteLine("Please enter your full name for Encryption and Decrytion: ");
            var myfullName = Console.ReadLine();

            //Converts fullName to a Byte array
            byte[] fullNamebytes = Encoding.ASCII.GetBytes(myfullName);
            foreach (byte b in fullNamebytes)
            {
                Console.WriteLine(b);
            }

            //QUESTION 9

            string unicodeString = myfullName;
            int[] cipher = new[] { 1, 1, 2, 3, 5, 8, 13 }; //Fibonacci Sequence
            string cipherasString = String.Join(",", cipher.Select(x => x.ToString())); //For display

            int encryptionDepth = 20;

            Encrypter encrypter = new Encrypter(unicodeString, cipher, encryptionDepth);

            //Deep Encryption
            string nameDeepEncryptWithCipher = Encrypter.DeepEncryptWithCipher(unicodeString, cipher, encryptionDepth);
            Console.WriteLine($"Deep Encrypted {encryptionDepth} times using the cipher {{{cipherasString}}} {nameDeepEncryptWithCipher}");

            //Deep Decryption
            string nameDeepDecryptWithCipher = Encrypter.DeepDecryptWithCipher(nameDeepEncryptWithCipher, cipher, encryptionDepth);
            Console.WriteLine($"Deep Decrypted {encryptionDepth} times using the cipher {{{cipherasString}}} {nameDeepDecryptWithCipher}");
        }
    }
}


