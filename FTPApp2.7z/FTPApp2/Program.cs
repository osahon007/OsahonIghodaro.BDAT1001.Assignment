﻿using FTPApp.Models.Utilities;
using System;
using FTPApp.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTPApp
{
    class Program
    {
        static void Main(string[] args)
        {

            //1) Converts Image to Byte
            //byte[] filetobytes = FTP.GetStreamBytes("C:\\Users\\Admin\\Desktop\\myimage.jpeg");

            //2) This outputs the list of ALL directories from FileZilla
            List<string> directories = FTP.GetDirectory(Constants.FTP.BaseUrl);

            //foreach (var directory in directories)

            //{
            //    Console.WriteLine(Constants.FTP.BaseUrl + "/" +  directory);
            //}

            //3) This Downloads Files From FileZilla. 
            //foreach (var directory in directories)

            //{
            //    try
            //    {
            //        //Displays the folder being downloaded on the Console
            //        Console.WriteLine(Constants.FTP.BaseUrl + "/" + directory);

            //        //Path to the remote file you will download. This downloads a file from ftp to local folder
            //        string remoteDownloadFilePath = "/" + directory + "/info.csv";

            //        //Path to a valid folder and the new file to be saved
            //        string localDownloadFileDestination = @"C:\Users\Admin\Desktop\Student Files\info.csv";
            //        Console.WriteLine(FTP.DownloadFile(Constants.FTP.BaseUrl + remoteDownloadFilePath, localDownloadFileDestination));
            //    }

            //    catch (Exception e)
            //    {
            //        Console.WriteLine(e.Message);
            //    }

            //}

            //4) Uploading a File from Local to FTP site
            //string localUploadFilePath = @"C:\Users\Admin\Desktop\Student Files\info2.csv";
            //string remoteUploadFileDestination = "/200470130 Osahon Ighodaro/info2.csv";
            //Console.WriteLine(FTP.UploadFile(localUploadFilePath, Constants.FTP.BaseUrl + remoteUploadFileDestination));


            //5) Search for a file named myimage.jpg in the entire directory
            //foreach (var directory in directories)
            //{
            //    Console.WriteLine(Constants.FTP.BaseUrl + "/" + directory);

            //    bool exists = FTP.FileExists(Constants.FTP.BaseUrl + $"/{directory}/myimage.jpg");

            //    //Does the file exist?
            //    if (exists == true)
            //    {
            //        Console.WriteLine("File exists");
            //    }
            //    else
            //    {
            //        Console.WriteLine("File does not exist");
            //    }

            //}

            //6) Downloads ALL files from directory, encodes this to Base64 and displays on console

            //foreach (var directory in directories)
            //{
            //    string remoteFileUrl = Constants.FTP.BaseUrl + $"/{directory}/myimage.jpg";

            //    //Search for a file named myimage.jpg
            //    bool exists = FTP.FileExists(remoteFileUrl);

            //    //Does the file exist?
            //    if (exists == true)
            //    {
            //        Console.WriteLine($"File exists - {remoteFileUrl}");
            //        //Download file bytes
            //        var imagebytes = FTP.DownloadFileBytes(remoteFileUrl);
            //        //Base64 encode files bytes
            //        string base64String = Convert.ToBase64String(imagebytes);
            //        //Output the result of the download
            //        Console.WriteLine(base64String);
            //    }
            //    else
            //    {
            //        Console.WriteLine($"File does not exist - {remoteFileUrl}");
            //    }
            //}


            //7) Searches for All files in FTP, downloads all images to a local folder, displays list of files with error on console
            //List<string> errors = new List<string>();

            //foreach (var directory in directories)
            //{
            //    Console.WriteLine(Constants.FTP.BaseUrl + "/" + directory);

            //    bool exists = FTP.FileExists(Constants.FTP.BaseUrl + $"/{directory}/myimage.jpg");

            //    //Does the file exist?
            //    if (exists == true)
            //    {
            //        Console.WriteLine("File exists");

            //        string remoteDownloadFilePath = "/" + directory + "/myimage.jpg";
            //        string localDownloadFileDestination = @"C:\Users\Admin\Desktop\Class Exercise\FTPApp\Contents\Images" + "\\" + directory + ".jpg";
            //        Console.WriteLine(FTP.DownloadFile(Constants.FTP.BaseUrl + remoteDownloadFilePath, localDownloadFileDestination));

            //    }
            //    else
            //    {
            //        errors.Add(directory + " - myimage.jpg does not exist");
            //        Console.WriteLine("File does not exist");
            //    }

            //    if (errors.Count > 0)
            //    {

            //        Console.WriteLine("Found errors");

            //        foreach (var error in errors)
            //        {
            //            Console.WriteLine(error);
            //        }
            //    }

            //}



            //8) This models a Student and displays the list of Students in FTP in a particular format 

            List<Student> students = new List<Student>();
            foreach (var directory in directories)

            {
                //Console.WriteLine(directory);

                // This creates a blank Student Object
                Student student = new Student();

                student.FromDirectory(directory);

                students.Add(student);

            }



            if (students.Count > 0)
            {
                //Displays how many students were found
                Console.WriteLine($"This list contains {students.Count} students");

                //This sorts by the LastName
                foreach (var student in students.OrderBy(x => x.LastName))
                {
                    Console.WriteLine(student);
                }
            }

            ////9) Downloading csv file content
            //List<Student> students = new List<Student>();
            //foreach (var directory in directories)
            //{
            //    Console.WriteLine(Constants.FTP.BaseUrl + "/" + directory);
            //    Student student = new Student();

            //    student.FromDirectory(directory);

            //    bool exists = FTP.FileExists(Constants.FTP.BaseUrl + $"/{directory}/info.csv");



            //    //Does the file exist?
            //    if (exists == true)
            //    {
            //        Console.WriteLine("  info.csv exists");

            //        var fileBytes = FTP.DownloadFileBytes(Constants.FTP.BaseUrl + $"/{directory}/info.csv");
            //        string infoCsvData = Encoding.UTF8.GetString(fileBytes, 0, fileBytes.Length);

            //        string[] lines = infoCsvData.Split("\r\n", StringSplitOptions.RemoveEmptyEntries);

            //        student.FromCSV(lines[1]);
            //        //student.Image.Save(@"C:\Users\Admin\Desktop\Class Exercise\FTPApp\Contents\Images" + "\\" + directory + ".jpg");
            //    }
            //    else
            //    {
            //        Console.WriteLine("File does not exist");
            //    }

            //    students.Add(student);

            //}

        }
    }
}
