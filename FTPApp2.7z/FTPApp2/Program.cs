﻿using FTPApp.Models.Utilities;
using System;
using FTPApp.Models;
using System.Collections.Generic;

namespace FTPApp
{
    class Program
    {
        static void Main(string[] args)
        {


            //Question 1 - This outputs the list of directories from FileZilla
            List<string> directories = FTP.GetDirectory(Constants.FTP.BaseUrl);

            // Question 2 - This checks if Osahon's files exists in the FTP directory

            if (FTP.FileExists(Constants.FTP.BaseUrl + "/200470130 Osahon Ighodaro/myimage.jpg"))
            {
                Console.WriteLine("myimage.jpg exits");

            }
            else
            {
                Console.WriteLine("myimage.jpg does not exist");
            }

            if (FTP.FileExists(Constants.FTP.BaseUrl + "/200470130 Osahon Ighodaro/info.csv"))
            {
                Console.WriteLine("info.csv exits");

            }
            else
            {
                Console.WriteLine("info.csv does not exist");
            }

            if (FTP.FileExists(Constants.FTP.BaseUrl + "/200470130 Osahon Ighodaro/info.html"))
            {
                Console.WriteLine("info.html exits");

            }
            else
            {
                Console.WriteLine("info.html does not exist");
            }



        }

    }

}
