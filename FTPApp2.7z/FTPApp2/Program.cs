﻿using FTPApp.Models.Utilities;
using System;
using FTPApp.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Newtonsoft.Json;


//ASSIGNMENT 3
namespace FTPApp
{
    class Program
    {
        static void Main(string[] args)
        {

  

            //A3_ 1.1) This outputs the list of ALL directories from FileZilla
            
            List<string> directories = FTP.GetDirectory(Constants.FTP.BaseUrl);
            /*
            foreach (var directory in directories)

            {
                Console.WriteLine(Constants.FTP.BaseUrl + "/" + directory);
            }

            */



            //A3_2.1 & 2.2) Search for Osahon's file named myimage.jpg and info.csv in the entire directory

            /*
           
            Console.WriteLine(Constants.FTP.BaseUrl + "/200470130 Osahon Ighodaro");

            bool exists = FTP.FileExists(Constants.FTP.BaseUrl + $"//200470130 Osahon Ighodaro/myimage.jpg");

            //Does the file exist?
            if (exists == true)
            {
                Console.WriteLine("  myimgae.jpg File exists");
            }
            else
            {
                Console.WriteLine("  myimgae.jpg File does not exist");
            }
                bool exists2 = FTP.FileExists(Constants.FTP.BaseUrl + $"//200470130 Osahon Ighodaro/info.csv");
                //Does the file exist?
            if (exists2 == true)
            {
                Console.WriteLine("  info.csv File exists");
            }
            else
            {
                Console.WriteLine("   info.csv file does not exist");
            }

            */



            //A3_2.4 - This has been done already in Assignment 2 and the codes are in the power point



            //A3_2.3
            //This models a Student and displays the list of Students in FTP in a particular format 

            List<Student> students = new List<Student>();
            foreach (var directory in directories)

            {
                //Console.WriteLine(directory);

                // This creates a blank Student Object
                Student student = new Student();

                student.FromDirectory(directory);

                students.Add(student);

            }

            /*
            //Agregrate Functions
            if (students.Count > 0)
            {
                // A3_5.1.a
                //Displays how many students were found
                Console.WriteLine($"This list contains {students.Count} students");

                // A3_5.1.b
                int snCount = 1;
                //This sorts by the LastName
                foreach (var student in students.OrderBy(x => x.LastName))
                {
                    Console.WriteLine(snCount++ + " " + student);
                }
            }

            

            //A3_5.1.d
            Student me = students.Find(x => x.StudentId == "200470130");
            me.MyRecord = true;

            Student findMe = students.Find(x => x.MyRecord == true);

            //A3_5.2
            //This writes the output into CSV
            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(@"C:\Users\Admin\Desktop\Student Files\students.csv"))
            {
                file.WriteLine("StudentId,FirstName,LastName,MyRecord");
                foreach (Student student in students.OrderBy(x => x.StudentId))

                {

                    file.WriteLine(student.ToCSV());

                }


            }
            //A3_5.3
            //This writes the output into Json
            string studentsListJson = JsonConvert.SerializeObject(students);
            //This exports the file to Json after conversion
            System.IO.File.WriteAllText(@"C:\Users\Admin\Desktop\Student Files\students.json", studentsListJson);
            

            */
            //A3_5.4
            //This help convert to xml and exports it
           
             System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(students.GetType());
             TextWriter writer = new StreamWriter(@"C:\Users\Admin\Desktop\Student Files\students.xml");
             x.Serialize(writer, students);


           
         
            
            /*
            //A3_5.5
            //Uploading a File from Local to FTP site
            string localUploadFilePath = @"C:\Users\Admin\Desktop\Student Files\students.csv";
            string remoteUploadFileDestination = "/200470130 Osahon Ighodaro/students.csv";
            Console.WriteLine(FTP.UploadFile(localUploadFilePath, Constants.FTP.BaseUrl + remoteUploadFileDestination));

            string localUploadFilePath2 = @"C:\Users\Admin\Desktop\Student Files\students.json";
            string remoteUploadFileDestination2 = "/200470130 Osahon Ighodaro/students.json";
            Console.WriteLine(FTP.UploadFile(localUploadFilePath2, Constants.FTP.BaseUrl + remoteUploadFileDestination2));
            */
            string localUploadFilePath3 = @"C:\Users\Admin\Desktop\Student Files\students.xml";
            string remoteUploadFileDestination3 = "/200470130 Osahon Ighodaro/students.xml";
            Console.WriteLine(FTP.UploadFile(localUploadFilePath3, Constants.FTP.BaseUrl + remoteUploadFileDestination3));



        }
    }
}
