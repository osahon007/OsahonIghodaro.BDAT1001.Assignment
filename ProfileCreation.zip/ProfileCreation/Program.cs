﻿using EncoderEncryterApp.Models;
using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Xml.Linq;

namespace ProfileCreation
{
    class Program
    {
        static void Main(string[] args)
        {
            

            //Get the location of the user's Desktop
            string imageDesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            //Build a image file path from the original image path
            FileInfo myFile = new FileInfo($"{imageDesktopPath}\\myimage.jpeg");

            //Provide an Image from a file on your Desktop
            Image image = Image.FromFile(myFile.FullName);

            //Convert Image to Base64 encoded text
            string base64image = Converter.ImageToBase64(image,ImageFormat.Jpeg);

            //Output the Base64 encoded text
            Console.WriteLine(base64image);

            //This creats a csv file and write tow rows of data in it
            //Ref : https://www.youtube.com/watch?v=gqDFD3TIrHY

            StringBuilder fileContent = new StringBuilder();
            fileContent.AppendLine("StudentId, FirstName, LastName, DateOfBirth, ImageData");
            fileContent.AppendLine("200470130, Osahon, Ighodaro, 11 Dec 1986,"+ base64image);
            string csvFilePath = @"info.csv";
            File.AppendAllText(csvFilePath, fileContent.ToString());

        }
    }
}
